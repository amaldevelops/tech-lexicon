#include <AT89X51.H>
 unsigned int tcount;
 unsigned char m;
 static unsigned char second,minute,hour;
 
 unsigned char code fseg[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
 unsigned char code segbit[]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
 unsigned char  disbuf[8]={0,0,0,0,0,0,0,0};


 //���ݴ���//
void sdata(void)
 {unsigned char b,c,num;

 	if(b==0)
	{	
	  b++;
	num=segbit[m];
 	 for(c=0;c<8;c++)
 	 	{P3_2=0;
	 	  P3_3=num&0x80;
 		  num<<=1;
	 	  P3_2=1;
	   }
	
	} 

	if(b==1)

	{  
	    b--;
	  if(m==2||m==5)
	  {num=0xbf;}
	  else
	   {num=fseg[disbuf[m]];}

 		for(c=0;c<8;c++)
 		  {  P3_2=0;
			 P3_3=num&0x80;
			 num<<=1;
			 P3_2=1;
 		  }
	
	}
	     m++;
	     if(m==8)
		 {m=0;
	   	  }
 }
//���ݴ���//







 //��ʱ0.1ms����λ//

 void delay (unsigned char h)
  {	while(h--);
  }
  //��ʱ0.1ms����λ//

 
 //�������//
void out(void)
 {P3_4=0;
  delay(50);
  P3_4=1;
 } 
//�������//



  //��������//
  void bcon(void)
   {if(P3_5==0)
     {delay(100);
	   if(P3_5==0)
	    {second=0;
		  while(P3_5==0);
		  
		}
	 }
	 disbuf[0]=second%10;
	disbuf[1]=second/10;

	if(P3_6==0)
     {delay(100);
	   if(P3_6==0)
	    {minute++;
		  while(P3_6==0);
		  if(minute==60)
		   {minute=0;
		   }
		}
	 }
	disbuf[3]=minute%10;
	disbuf[4]=minute/10;


	 if(P3_7==0)
     {delay(100);
	   if(P3_7==0)
	    {hour++;
		  while(P3_7==0);
		   if(hour==24)
		    {hour=0;
			}
		}
	 }
	
	disbuf[6]=hour%10;
	disbuf[7]=hour/10;
	
	disbuf[0]=second%10;
	disbuf[1]=second/10;
	disbuf[3]=minute%10;
	disbuf[4]=minute/10;
	disbuf[6]=hour%10;
	disbuf[7]=hour/10;

   }
   //���̿���//

  
  
  
  //������//



void main(void)
 {	
  TMOD=0x02;
  TH0=0x06;
  TL0=0x06;
  TR0=1;
  ET0=1;
  EA=1;

  while(1)
  {
   bcon();
   sdata();
   out();

  }
  while(1);

 } 
 //������//


 //�жϳ���//

 void t0(void) interrupt 1 using 0 
  {	tcount++;

    if(tcount==4000)
	  {tcount=0;
	    second++;

		 if(second==60)
		  {second=0;
		   minute++;

		    if(minute==60)
			 {minute=0;
			  hour++;

			  if(hour==24)
			   {hour=0;
			   }
			 }
		  }
	  }
	}



  	
  //�жϳ���//